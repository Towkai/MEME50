#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include "slave.h"

int init_module() {

	printk("hello\n");
	slave_test();

	return 0;
}

void cleanup_module() {
	printk("bye\n");
}

MODULE_LICENSE("GPL");
