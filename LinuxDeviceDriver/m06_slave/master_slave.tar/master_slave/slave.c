#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>

void slave_test(void){
	printk("slave_test()\n");
}

int init_module() {

	printk("hello\n");

	return 0;
}

void cleanup_module() {
	printk("bye\n");
}

MODULE_LICENSE("GPL");
EXPORT_SYMBOL(slave_test);
