void slave_test(void);

